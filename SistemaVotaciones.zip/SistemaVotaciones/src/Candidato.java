public class Candidato {
    private String nombre;
    private String apellido;
    private String fechaNacimiento;
    private String numeroIdentificacion;
    private String genero;
    private String numeroTelefono;
    private String correoElectronico;
    private String fechaRegistro;
    private String partidoPolitico;

    public Candidato(String nombre, String apellido, String fechaNacimiento, String numeroIdentificacion, String genero, String numeroTelefono, String correoElectronico, String fechaRegistro, String partidoPolitico) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.fechaNacimiento = fechaNacimiento;
        this.numeroIdentificacion = numeroIdentificacion;
        this.genero = genero;
        this.numeroTelefono = numeroTelefono;
        this.correoElectronico = correoElectronico;
        this.fechaRegistro = fechaRegistro;
        this.partidoPolitico = partidoPolitico;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getNumeroIdentificacion() {
        return numeroIdentificacion;
    }

    public String getGenero() {
        return genero;
    }

    public String getNumeroTelefono() {
        return numeroTelefono;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public String getFechaRegistro() {
        return fechaRegistro;
    }

    public String getPartidoPolitico() {
        return partidoPolitico;
    }
}