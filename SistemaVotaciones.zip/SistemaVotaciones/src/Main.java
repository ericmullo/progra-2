import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ProcesoElectoral procesoElectoral = new ProcesoElectoral("2022", "01/01/2022");
        String[] partidos = {"Partido 1", "Partido 2", "Partido 3"};
        procesoElectoral.setPartidosPoliticos(partidos);
        Scanner scanner = new Scanner(System.in);
        int opcion = 0;

        while (opcion != 7) {
            System.out.println("Menú de opciones:");
            System.out.println("1) Registro de votantes");
            System.out.println("2) Emitir voto");
            System.out.println("3) Registrar su candidatura");
            System.out.println("4) Información del proceso electoral");
            System.out.println("5) Avanzar hora al reloj");
            System.out.println("6) Conocer los resultados oficiales de las elecciones");
            System.out.println("7) Salir");
            System.out.print("Ingrese una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del votante: ");
                    String nombreVotante = scanner.nextLine();
                    System.out.print("Ingrese el apellido del votante: ");
                    String apellidoVotante = scanner.nextLine();
                    System.out.print("Ingrese el número de identificación del votante: ");
                    String numeroIdentificacionVotante = scanner.nextLine();

                    Votante votante = new Votante(nombreVotante, apellidoVotante, numeroIdentificacionVotante);
                    procesoElectoral.agregarVotante(votante);
                    System.out.println("El votante ha sido registrado exitosamente.");
                    break;
                case 2:
                    System.out.print("Ingrese el número de identificación del votante: ");
                    String numeroIdentificacion = scanner.nextLine();
                    System.out.print("Ingrese el nombre del candidato: ");
                    String candidato = scanner.nextLine();
                    System.out.print("Ingrese el tipo de voto (Válido, Nulo, Blanco): ");
                    String tipoVoto = scanner.nextLine();

                    Votante votanteEmitirVoto = null;
                    for (Votante v : procesoElectoral.getVotantes()) {
                        if (v.getNumeroIdentificacion().equals(numeroIdentificacion)) {
                            votanteEmitirVoto = v;
                            break;
                        }
                    }

                    if (votanteEmitirVoto != null) {
                        procesoElectoral.emitirVoto(votanteEmitirVoto, candidato, tipoVoto);
                    } else {
                        System.out.println("El votante no está registrado en el sistema.");
                    }
                    break;
                case 3:
                    System.out.print("Ingrese el nombre del candidato: ");
                    String nombreCandidato = scanner.nextLine();
                    System.out.print("Ingrese el apellido del candidato: ");
                    String apellidoCandidato = scanner.nextLine();
                    System.out.print("Ingrese la fecha de nacimiento del candidato (Dia/Mes/Año): ");
                    String fechaNacimientoCandidato = scanner.nextLine();
                    System.out.print("Ingrese el número de identificación del candidato: ");
                    String numeroIdentificacionCandidato = scanner.nextLine();
                    System.out.print("Ingrese el género del candidato (Masculino, Femenino): ");
                    String generoCandidato = scanner.nextLine();
                    System.out.print("Ingrese el número de teléfono del candidato: ");
                    String numeroTelefonoCandidato = scanner.nextLine();
                    System.out.print("Ingrese el correo electrónico del candidato: ");
                    String correoElectronicoCandidato = scanner.nextLine();
                    System.out.print("Ingrese el número del partido político: ");
                    procesoElectoral.mostrarPartidos();
                    int opcionPartidoPolitico = scanner.nextInt();
                    String partidoPoliticoCandidato = procesoElectoral.getPartidosPoliticos()[opcionPartidoPolitico-1];

                    Candidato candidatoNuevo = new Candidato(nombreCandidato, apellidoCandidato, fechaNacimientoCandidato,
                            numeroIdentificacionCandidato, generoCandidato, numeroTelefonoCandidato,
                            correoElectronicoCandidato, "01/01/2022", partidoPoliticoCandidato);
                    procesoElectoral.agregarCandidato(candidatoNuevo);
                    break;
                case 4:
                    System.out.println("Información del proceso electoral:");
                    System.out.println("Periodo electoral: " + procesoElectoral.getPeriodoElectoral());
                    System.out.println("Fecha: " + procesoElectoral.getFecha());
                    System.out.println("Candidatos:");
                    for (Candidato candidato2 : procesoElectoral.getCandidatos()) {
                        System.out.println("- " + candidato2.getNombre() + " " + candidato2.getApellido() + " ("
                                + candidato2.getPartidoPolitico() + ")");
                    }
                    break;
                case 5:
                    procesoElectoral.avanzarHora();
                    System.out.println("La hora ha sido avanzada.");
                    break;
                case 6:
                    procesoElectoral.mostrarResultados();
                    break;
                case 7:
                    System.out.println("¡Gracias por utilizar el programa de elecciones!");
                    break;
                default:
                    System.out.println("Opción inválida. Por favor, ingrese una opción válida.");
                    break;
            }
        }
    }
}