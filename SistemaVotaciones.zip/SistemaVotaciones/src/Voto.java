public class Voto {
    private String candidato;
    private String tipoVoto;

    public Voto(String candidato, String tipoVoto) {
        this.candidato = candidato;
        this.tipoVoto = tipoVoto;
    }

    public String getCandidato() {
        return candidato;
    }

    public String getTipoVoto() {
        return tipoVoto;
    }
}