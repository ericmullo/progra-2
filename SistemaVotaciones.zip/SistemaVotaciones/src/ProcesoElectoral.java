import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ProcesoElectoral {
    private String periodoElectoral;
    private String fecha;
    private List<Candidato> candidatos;
    private List<Votante> votantes;
    private List<Voto> votos;

    private String[] partidosPoliticos;

    public ProcesoElectoral(String periodoElectoral, String fecha) {
        this.periodoElectoral = periodoElectoral;
        this.fecha = fecha;
        this.candidatos = new ArrayList<>();
        this.votantes = new ArrayList<>();
        this.votos = new ArrayList<>();
    }

    public String getPeriodoElectoral() {
        return periodoElectoral;
    }

    public void setPeriodoElectoral(String periodoElectoral) {
        this.periodoElectoral = periodoElectoral;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public List<Candidato> getCandidatos() {
        return candidatos;
    }

    public void setCandidatos(List<Candidato> candidatos) {
        this.candidatos = candidatos;
    }

    public List<Votante> getVotantes() {
        return votantes;
    }

    public void setVotantes(List<Votante> votantes) {
        this.votantes = votantes;
    }

    public List<Voto> getVotos() {
        return votos;
    }

    public void setVotos(List<Voto> votos) {
        this.votos = votos;
    }

    public String[] getPartidosPoliticos() {
        return partidosPoliticos;
    }

    public void setPartidosPoliticos(String[] partidosPoliticos) {
        this.partidosPoliticos = partidosPoliticos;
    }

    public void agregarCandidato(Candidato candidato) {
        if(!validacionCandidatoPorID(candidato.getNumeroIdentificacion())) {
            if(manejoValidacionEdad(candidato.getFechaNacimiento())) {
                if(!manejoValidacionExisteEnPartido(candidato.getPartidoPolitico())) {
                    candidatos.add(candidato);
                    System.out.println("El candidato ha sido registrado exitosamente.");
                }
            }
        } else {
            System.out.println("Candidato ya existente");
        }
    }

    public void agregarVotante(Votante votante) {
        votantes.add(votante);
    }

    public void emitirVoto(Votante votante, String candidato, String tipoVoto) {
        if (validarVotante(votante)) {
            Voto voto = new Voto(candidato, tipoVoto);
            votos.add(voto);
            System.out.println("Su voto ha sido registrado exitosamente.");
        }
    }

    private boolean validarVotante(Votante votante) {
        for (Votante v : votantes) {
            if (v.getNumeroIdentificacion().equals(votante.getNumeroIdentificacion())) {
                System.out.println("El votante " + votante.getNombre() + " ya ha ejercido su voto.");
                return false;
            }
        }
        return true;
    }

    public void mostrarResultados() {
        int votosBlancos = 0;
        int votosNulos = 0;
        int votosValidos = 0;
        int totalVotos = votos.size();

        for (Voto voto : votos) {
            if (voto.getTipoVoto().equals("Blanco")) {
                votosBlancos++;
            } else if (voto.getTipoVoto().equals("Nulo")) {
                votosNulos++;
            } else {
                votosValidos++;
            }
        }

        System.out.println("Resultados Electorales:");
        System.out.println("Cantidad de votos en blanco: " + votosBlancos);
        System.out.println("Cantidad de votos nulos: " + votosNulos);
        System.out.println("Cantidad de votos válidos: " + votosValidos);

        for (Candidato candidato : candidatos) {
            int votosCandidato = contarVotosCandidato(candidato.getNombre());
            System.out.println("Cantidad de votos obtenidos por " + candidato.getNombre() + ": " + votosCandidato);
        }

        Candidato candidatoMasVotado = obtenerCandidatoMasVotado();
        System.out.println("Candidato más votado: " + candidatoMasVotado.getNombre());

        Candidato candidatoMenosVotado = obtenerCandidatoMenosVotado();
        System.out.println("Candidato menos votado: " + candidatoMenosVotado.getNombre());

        double porcentajeVotosBlancos = (votosBlancos / (double) totalVotos) * 100;
        double porcentajeVotosNulos = (votosNulos / (double) totalVotos) * 100;
        double porcentajeVotosValidos = (votosValidos / (double) totalVotos) * 100;

        System.out.println("Porcentaje de votos en blanco: " + porcentajeVotosBlancos + "%");
        System.out.println("Porcentaje de votos nulos: " + porcentajeVotosNulos + "%");
        System.out.println("Porcentaje de votos válidos: " + porcentajeVotosValidos + "%");
    }

    private int contarVotosCandidato(String nombreCandidato) {
        int contador = 0;
        for (Voto voto : votos) {
            if (voto.getCandidato().equals(nombreCandidato)) {
                contador++;
            }
        }
        return contador;
    }

    private Candidato obtenerCandidatoMasVotado() {
        Candidato candidatoMasVotado = candidatos.get(0);
        int maxVotos = contarVotosCandidato(candidatoMasVotado.getNombre());

        for (Candidato candidato : candidatos) {
            int votosCandidato = contarVotosCandidato(candidato.getNombre());
            if (votosCandidato > maxVotos) {
                maxVotos = votosCandidato;
                candidatoMasVotado = candidato;
            }
        }

        return candidatoMasVotado;
    }

    private Candidato obtenerCandidatoMenosVotado() {
        Candidato candidatoMenosVotado = candidatos.get(0);
        int minVotos = contarVotosCandidato(candidatoMenosVotado.getNombre());

        for (Candidato candidato : candidatos) {
            int votosCandidato = contarVotosCandidato(candidato.getNombre());
            if (votosCandidato < minVotos) {
                minVotos = votosCandidato;
                candidatoMenosVotado = candidato;
            }
        }

        return candidatoMenosVotado;
    }

    public void avanzarHora() {
        System.out.println("Avanzar hora");
    }

    public void mostrarPartidos() {
        if (hayPartidos()) {
            System.out.println("Lista de partidos:");

            for (int i = 0; i < partidosPoliticos.length; i++) {
                System.out.println((i + 1) + ". " + partidosPoliticos[i]);
            }
        } else {
            System.out.println("No hay partidos registrados.");
        }
    }

    private boolean hayPartidos() {
        return partidosPoliticos != null && partidosPoliticos.length > 0;
    }

    private boolean validacionCandidatoPorID(String id) {
        for (Candidato candidato : this.candidatos) {
            if(candidato.getNumeroIdentificacion() == id) {
                return true;
            }
        }
        return false;
    }

    private static LocalDate convertirCadenaAFecha(String fechaStr) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return LocalDate.parse(fechaStr, formatter);
    }

    // Método para validar si la edad es mayor a 17 años
    private static boolean validarEdad(LocalDate fechaNacimiento) {
        LocalDate fechaActual = LocalDate.now();

        int diferenciaDeAnios = fechaActual.getYear() - fechaNacimiento.getYear();

        return diferenciaDeAnios > 17 || (diferenciaDeAnios == 17 && fechaNacimiento.getDayOfYear() <= fechaActual.getDayOfYear());
    }

    public boolean manejoValidacionEdad(String fecha) {
        LocalDate fechaNacimiento = convertirCadenaAFecha(fecha);
        boolean esMayorEdad = validarEdad(fechaNacimiento);
        if (esMayorEdad) {
            System.out.println("La persona es mayor de 17 años.");
        } else {
            System.out.println("La persona no es mayor de 17 años.");
        }
        return esMayorEdad;
    }

    private boolean manejoValidacionExisteEnPartido(String partido) {
        for (Candidato candidato : this.candidatos) {
            if(candidato.getPartidoPolitico() == partido) {
                System.out.println("Ya existe candidato en " + partido);
                return true;
            }
        }
        return false;
    }
}